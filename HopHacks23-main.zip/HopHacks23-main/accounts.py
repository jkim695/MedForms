patients = {}
accounts = {}